package com.zys.yanku.lslayout;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private String[] mDatas = new String[]{
            "法务110",
            "电话咨询",
            "案件代理",
            "法律顾问",
            "代写文书",
            "合同拟定审核",
            "律师函"
    };
    private FlowLayout mFlowLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mFlowLayout = (FlowLayout) findViewById(R.id.flow_layout);

        // 循环添加TextView到容器
        for (int i = 0; i < mDatas.length; i++) {
            final View view = View.inflate(this, R.layout.item_text, null);
            final TextView textView = (TextView) view.findViewById(R.id.text);
            textView.setText(mDatas[i]);
            final ImageView imageView = (ImageView) view.findViewById(R.id.gx);
            ImageView biao = (ImageView) view.findViewById(R.id.biao);
            TextView name = (TextView) view.findViewById(R.id.name);
            if (i == 0) {
                biao.setVisibility(View.VISIBLE);
                name.setVisibility(View.VISIBLE);
            } else {
                biao.setVisibility(View.GONE);
                name.setVisibility(View.GONE);
            }

            // 设置点击事件
            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    int childCount = mFlowLayout.getChildCount();
                    for (int i = 0; i < childCount; i++) {
                        mFlowLayout.getChildAt(i).findViewById(R.id.text).setEnabled(true);
                        mFlowLayout.getChildAt(i).findViewById(R.id.gx).setVisibility(View.GONE);
                    }
                    textView.setEnabled(false);
                    imageView.setVisibility(View.VISIBLE);
                }
            });

            mFlowLayout.addView(view);

        }
    }
}
